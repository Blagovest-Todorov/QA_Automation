﻿
using NUnit.Framework;

namespace LiveDemo
{
    [SetUpFixture]
    public class AssemblyInitialize
    {
        [OneTimeSetUp]
        public void AssemblyInit() 
        {
            //once per Run
        }

        [OneTimeTearDown]
        public void AssemblyCleanUp() 
        {
         // Once per run // this performs once at the end of each class
        }
    }
}
