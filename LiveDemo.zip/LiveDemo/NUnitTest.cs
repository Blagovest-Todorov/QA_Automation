﻿using Bank;
using NUnit.Framework;


namespace LiveDemo
{
    [TestFixture]
    class NUnitTest
    {
        [OneTimeSetUp]
        public void ClassInit() 
        {
          //one per class
        }
        
        
        [SetUp]  // method that will perform before each test
        public void SetUp() 
        {
          //one per test
        }

        [Test]
        [Ignore("dont performBug_1067")]
        [TestCase(1, 1)]
        public void AccountAmount_CreateNewAccount(int a, int b)
        {
            //Arrange , create object and give him value //var account = new Account(1000);
            //we set entry test data
            var account = new BankAccount(1000);

            //ACT ->  
            var actualAmount = account.Amount;
            var expectedAmount = 1000;
            //Assert(expectedAmount, actualAmount)   -> estimate the expected and actual
            //Assert.AreEqual(1000, account.Amount);  //on the left expected on the right actual
            //Assert.That(actualAmount == expectedAmount);
            Assert.AreEqual(expectedAmount, actualAmount);
        }

        [Test]
        public void SecondTest() 
        {
            
        }

        [TearDown]
        public void Teardown() 
        {
           
        }

        [OneTimeTearDown]
        public void ClassCleanup() 
        {
        
        }
    }
}
