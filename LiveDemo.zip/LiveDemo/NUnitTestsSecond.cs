﻿using Bank;
using NUnit.Framework;


namespace LiveDemo
{
    [TestFixture]
    class NUnitTestsSecond
    {
        [OneTimeSetUp]
        public void ClassInit() 
        {
          //one per class
        }
        
        
        [SetUp]  // method that will perform before each test
        public void SetUp() 
        {
          //one per test
        }

        [Test]
        public void FirstTest()
        {
            var account = new BankAccount(1000);
            Assert.AreEqual(1000, account.Amount);  //on the left expected on the right actual
        }

        [Test]
        public void SecondTest() 
        {
            
        }

        [TearDown]
        public void Teardown() 
        {
           
        }

        [OneTimeTearDown]
        public void ClassCleanup() 
        {
        
        }
    }
}
