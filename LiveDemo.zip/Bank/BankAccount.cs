﻿
namespace Bank
{
    public class BankAccount
    {
        //private int ammount;
        public int Amount { get; set; }
        public BankAccount() 
        {
        
        }

        public BankAccount(int sum)
        {
            this.Amount = sum;
        }
    }
}
